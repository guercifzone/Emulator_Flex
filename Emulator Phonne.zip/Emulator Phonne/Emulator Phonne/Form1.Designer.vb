﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.RunToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LanguageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HtmlToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.JsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.XMLToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveAsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AndroidToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.IOSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenfileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ApkToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.IosToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FACEBOOKGROUPToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.WebBrowser1 = New System.Windows.Forms.WebBrowser()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'RichTextBox1
        '
        Me.RichTextBox1.Dock = System.Windows.Forms.DockStyle.Left
        Me.RichTextBox1.Location = New System.Drawing.Point(0, 24)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(561, 517)
        Me.RichTextBox1.TabIndex = 0
        Me.RichTextBox1.Text = ""
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RunToolStripMenuItem, Me.LanguageToolStripMenuItem, Me.SaveAsToolStripMenuItem, Me.OpenfileToolStripMenuItem, Me.AboutToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(937, 24)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'RunToolStripMenuItem
        '
        Me.RunToolStripMenuItem.Name = "RunToolStripMenuItem"
        Me.RunToolStripMenuItem.Size = New System.Drawing.Size(40, 20)
        Me.RunToolStripMenuItem.Text = "Run"
        '
        'LanguageToolStripMenuItem
        '
        Me.LanguageToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HtmlToolStripMenuItem, Me.JsToolStripMenuItem, Me.XMLToolStripMenuItem})
        Me.LanguageToolStripMenuItem.Name = "LanguageToolStripMenuItem"
        Me.LanguageToolStripMenuItem.Size = New System.Drawing.Size(71, 20)
        Me.LanguageToolStripMenuItem.Text = "Language"
        '
        'HtmlToolStripMenuItem
        '
        Me.HtmlToolStripMenuItem.Name = "HtmlToolStripMenuItem"
        Me.HtmlToolStripMenuItem.Size = New System.Drawing.Size(101, 22)
        Me.HtmlToolStripMenuItem.Text = "Html"
        '
        'JsToolStripMenuItem
        '
        Me.JsToolStripMenuItem.Name = "JsToolStripMenuItem"
        Me.JsToolStripMenuItem.Size = New System.Drawing.Size(101, 22)
        Me.JsToolStripMenuItem.Text = "JS"
        '
        'XMLToolStripMenuItem
        '
        Me.XMLToolStripMenuItem.Name = "XMLToolStripMenuItem"
        Me.XMLToolStripMenuItem.Size = New System.Drawing.Size(101, 22)
        Me.XMLToolStripMenuItem.Text = "XML"
        '
        'SaveAsToolStripMenuItem
        '
        Me.SaveAsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AndroidToolStripMenuItem, Me.IOSToolStripMenuItem})
        Me.SaveAsToolStripMenuItem.Name = "SaveAsToolStripMenuItem"
        Me.SaveAsToolStripMenuItem.Size = New System.Drawing.Size(59, 20)
        Me.SaveAsToolStripMenuItem.Text = "Save As"
        Me.SaveAsToolStripMenuItem.Visible = False
        '
        'AndroidToolStripMenuItem
        '
        Me.AndroidToolStripMenuItem.Name = "AndroidToolStripMenuItem"
        Me.AndroidToolStripMenuItem.Size = New System.Drawing.Size(117, 22)
        Me.AndroidToolStripMenuItem.Text = "Android"
        '
        'IOSToolStripMenuItem
        '
        Me.IOSToolStripMenuItem.Name = "IOSToolStripMenuItem"
        Me.IOSToolStripMenuItem.Size = New System.Drawing.Size(117, 22)
        Me.IOSToolStripMenuItem.Text = "IOS"
        '
        'OpenfileToolStripMenuItem
        '
        Me.OpenfileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ApkToolStripMenuItem, Me.IosToolStripMenuItem1})
        Me.OpenfileToolStripMenuItem.Name = "OpenfileToolStripMenuItem"
        Me.OpenfileToolStripMenuItem.Size = New System.Drawing.Size(50, 20)
        Me.OpenfileToolStripMenuItem.Text = "BuiLD"
        '
        'ApkToolStripMenuItem
        '
        Me.ApkToolStripMenuItem.Name = "ApkToolStripMenuItem"
        Me.ApkToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ApkToolStripMenuItem.Text = "Apk"
        '
        'IosToolStripMenuItem1
        '
        Me.IosToolStripMenuItem1.Name = "IosToolStripMenuItem1"
        Me.IosToolStripMenuItem1.Size = New System.Drawing.Size(152, 22)
        Me.IosToolStripMenuItem1.Text = "Ios"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FACEBOOKGROUPToolStripMenuItem})
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(52, 20)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'FACEBOOKGROUPToolStripMenuItem
        '
        Me.FACEBOOKGROUPToolStripMenuItem.Name = "FACEBOOKGROUPToolStripMenuItem"
        Me.FACEBOOKGROUPToolStripMenuItem.Size = New System.Drawing.Size(176, 22)
        Me.FACEBOOKGROUPToolStripMenuItem.Text = "FACEBOOK GROUP"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Emulator_Phonne.My.Resources.Resources.phonn
        Me.PictureBox1.Location = New System.Drawing.Point(567, 24)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(364, 505)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 2
        Me.PictureBox1.TabStop = False
        '
        'WebBrowser1
        '
        Me.WebBrowser1.Location = New System.Drawing.Point(590, 72)
        Me.WebBrowser1.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser1.Name = "WebBrowser1"
        Me.WebBrowser1.Size = New System.Drawing.Size(316, 409)
        Me.WebBrowser1.TabIndex = 3
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(937, 541)
        Me.Controls.Add(Me.WebBrowser1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.RichTextBox1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.Text = "Emulator flex"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents RichTextBox1 As System.Windows.Forms.RichTextBox
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents RunToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents WebBrowser1 As System.Windows.Forms.WebBrowser
    Friend WithEvents LanguageToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HtmlToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents JsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents XMLToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveAsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AndroidToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents IOSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenfileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents FACEBOOKGROUPToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ApkToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents IosToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem

End Class
