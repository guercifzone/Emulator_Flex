﻿Imports FastColoredTextBoxNS
Imports System.IO
Imports System.Net

Public Class Form1
    Dim n As New FastColoredTextBoxNS.FastColoredTextBox
    'Dim ata As SaveFileDialog
    Dim sima As OpenFileDialog

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim MSDNpage As String = WebBrowser1.DocumentText
        WebBrowser1.ScriptErrorsSuppressed = True
        n.Text = My.Resources.webviewContent
        n.Dock = DockStyle.Fill : n.Language = FastColoredTextBoxNS.Language.HTML
        RichTextBox1.Controls.Add(n)
    End Sub

#Region "RishTextBox Language "
    Private Sub HtmlToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HtmlToolStripMenuItem.Click
        n.Text = My.Resources.webviewContent
        CType(Me.RichTextBox1.Controls.Item(0), FastColoredTextBoxNS.FastColoredTextBox).Language = Language.HTML
    End Sub

    Private Sub JsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles JsToolStripMenuItem.Click
        n.Text = My.Resources.js
        CType(Me.RichTextBox1.Controls.Item(0), FastColoredTextBoxNS.FastColoredTextBox).Language = Language.JS
    End Sub

    ' Private Sub PhpToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PhpToolStripMenuItem.Click
    '  n.Text = My.Resources.php
    '  CType(Me.RichTextBox1.Controls.Item(0), FastColoredTextBoxNS.FastColoredTextBox).Language = Language.PHP
    ' End Sub

    '   Private Sub VBToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles VBToolStripMenuItem.Click
    '  n.Text = My.Resources.vb
    '  CType(Me.RichTextBox1.Controls.Item(0), FastColoredTextBoxNS.FastColoredTextBox).Language = Language.VB
    'End Sub

    ' Private Sub LuaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LuaToolStripMenuItem.Click
    '  n.Text = My.Resources.lua
    ' CType(Me.RichTextBox1.Controls.Item(0), FastColoredTextBoxNS.FastColoredTextBox).Language = Language.Lua
    'End Sub

    'Private Sub CToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CToolStripMenuItem.Click
    ' n.Text = My.Resources.sharp
    'CType(Me.RichTextBox1.Controls.Item(0), FastColoredTextBoxNS.FastColoredTextBox).Language = Language.CSharp
    'End Sub

    '  Private Sub SQLToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SQLToolStripMenuItem.Click
    '  n.Text = My.Resources.sql
    '  CType(Me.RichTextBox1.Controls.Item(0), FastColoredTextBoxNS.FastColoredTextBox).Language = Language.SQL
    '  End Sub

    Private Sub XMLToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles XMLToolStripMenuItem.Click
        n.Text = My.Resources.AndroidManifest
        CType(Me.RichTextBox1.Controls.Item(0), FastColoredTextBoxNS.FastColoredTextBox).Language = Language.XML
    End Sub


#End Region
    Private Sub RunToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RunToolStripMenuItem.Click
        WebBrowser1.DocumentText = n.Text
        SaveAsToolStripMenuItem.Visible = True

    End Sub


    Private Sub AndroidToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AndroidToolStripMenuItem.Click
        SaveFileDialog1.DefaultExt = "*.html"
        SaveFileDialog1.Filter = "HTML FILES|*.html"
        SaveFileDialog1.CreatePrompt = True
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            My.Computer.FileSystem.WriteAllText(SaveFileDialog1.FileName, WebBrowser1.DocumentText, True)
        End If
    End Sub

    Private Sub FACEBOOKGROUPToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FACEBOOKGROUPToolStripMenuItem.Click
        Dim url As String = "https://www.facebook.com/groups/devearab"
        Process.Start(url)
    End Sub

    Private Sub IOSToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles IOSToolStripMenuItem.Click
        SaveFileDialog1.DefaultExt = "*.html"
        SaveFileDialog1.Filter = "HTML FILES|*.html"
        SaveFileDialog1.CreatePrompt = True
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            My.Computer.FileSystem.WriteAllText(SaveFileDialog1.FileName, WebBrowser1.DocumentText, True)
        End If
    End Sub

    Private Sub ApkToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ApkToolStripMenuItem.Click
        Form2.Show()
    End Sub

    Private Sub IosToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles IosToolStripMenuItem1.Click

    End Sub
End Class
