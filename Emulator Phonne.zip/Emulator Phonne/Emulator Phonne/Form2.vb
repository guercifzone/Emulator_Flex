﻿Public Class Form2

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        OpenFileDialog1.ShowDialog()
        Dim file As String = OpenFileDialog1.FileName
        TextBox1.Text = file
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim type As String = TextBox2.Text
        If TextBox2.Text = "" Then MsgBox("No file type selected") Else 
        If MsgBox(TextBox1.Text + " shall be converted into . " + type + "file.") Then
            Dim oldFile As String = Mid(TextBox1.Text, 1, Len(TextBox1.Text) - 3)
            FileCopy(TextBox1.Text, oldFile + type)
        End If
    End Sub
End Class