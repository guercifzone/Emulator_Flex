﻿Imports System.IO
Public Class nnnnnn


    Dim masar As String = OpenFileDialog1.FileName
    Dim rat As String = OpenFileDialog1.Filter

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click


        Dim myFiles As String()
        myFiles = IO.Directory.GetFiles(masar, rat)
        Dim newFilePath As String
        For Each filepath As String In myFiles
            newFilePath = filepath.Replace(".zip", ".aia")
            System.IO.File.Move(filepath, newFilePath)
            MsgBox("ok is d'onne")
        Next



    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        OpenFileDialog1.DefaultExt = "*.zip"
        OpenFileDialog1.Filter = "zip files |*.zip"
        If OpenFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then

            Label1.Text = masar
        End If

    End Sub

    Private Sub build_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class